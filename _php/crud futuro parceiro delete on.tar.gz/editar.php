<?php
// including the database connection file
include_once("conexao.php");

if(isset($_POST['update']))
{
    $id = mysqli_real_escape_string($mysqli, $_POST['id']);

	$nome_empresa = mysqli_real_escape_string($mysqli, $_POST['NOME_EMPRESA']);
	$email = mysqli_real_escape_string($mysqli, $_POST['EMAIL_EMPRESA']);
	$nome_contato = mysqli_real_escape_string($mysqli, $_POST['NOME_CONTATO']);
	$motivo_contato = mysqli_real_escape_string($mysqli, $_POST['MOTIVO_CONTATO']);

	// checking empty fields
	if(empty($nome_empresa) || empty($email) || empty($nome_contato) || empty($motivo_contato)) {

		if(empty($nome_empresa)) {
			echo "<font color='red'>O campo nome está vazio.</font><br/>";
		}

		if(empty($email)) {
			echo "<font color='red'>O campo email está vazio.</font><br/>";
		}

		if(empty($nome_contato)) {
			echo "<font color='red'>O campo contato está vazio.</font><br/>";
		}
		if(empty($motivo_contato)) {
			echo "<font color='red'>O campo motivo está vazio.</font><br/>";
		}
	} else {
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE FUTUROS_PARCEIROS SET NOME_EMPRESA='$nome_empresa',EMAIL_EMPRESA='$email',NOME_CONTATO='$nome_contato',MOTIVO_CONTATO='$motivo_contato' WHERE FUTUROS_PARCEIROS.NOME_EMPRESA=$$nome_empresa");

		//redirectig to the display page. In our case, it is index.php
		//header("Location: index.php");
		header("Location:../select_dados_futuro_parceiro.php");
	}
}
?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM users WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$name = $res['name'];
	$age = $res['age'];
	$email = $res['email'];
}
?>
<html>
<head>
	<title>Edit Data</title>
</head>

<body>
	<a href="index.php">Home</a>
	<br/><br/>

	<form name="form1" method="post" action="editar.php">
		<table border="0">
			<tr>
				<td>Name</td>
				<td><input type="text" name="NOME_EMPRESA" value="<?php echo $nome_empresa;?>"></td>
			</tr>
			<tr>
				<td>E-mail</td>
				<td><input type="text" name="EMAIL_EMPRESA" value="<?php echo $email;?>"></td>
			</tr>
			<tr>
				<td>Nome contato</td>
				<td><input type="text" name="NOME_CONTATO" value="<?php echo $nome_contato;?>"></td>
			</tr>
			<tr>
				<td>Motivo contato</td>
				<td><input type="text" name="MOTIVO_CONTATO" value="<?php echo $motivo_contato;?>"></td>
			</tr>
			<tr>
				<td><input type="hidden" name="NOME_EMPRESA" value=<?php echo $_GET['NOME_EMPRESA'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
