<?php

include("conexao.php");
$id = $_GET['ID'];
//echo "<script type='text/javascript'>alert('ocorreu um erro, a variavel $id deve estar vazia');</script>";

$result = mysqli_query($mysqli,"DELETE FROM `FUTURO_PARCEIRO` WHERE `FUTURO_PARCEIRO`.`ID_EFP` = $id");
//$result = mysqli_query($mysqli, "DELETE FROM 'FUTURO_PARCEIRO' WHERE ID_EFP = '$id'");
header("Location:../select_dados_futuro_parceiro.php");


/*if (isset($_GET['NOME_EMPRESA'])) {
  $id = $_GET["NOME_EMPRESA"];
}
//$id = $_GET["NOME_EMPRESA"];
//$id = $_REQUEST["NOME_EMPRESA"];
//$nome_empresa = $_GET["NOME_EMPRESA"];

if($id){
$result = mysqli_query($mysqli, "DELETE FROM FUTURO_PARCEIRO WHERE FUTURO_PARCEIRO.NOME_EMPRESA = '$id'");

echo "<script type='text/javascript'>alert('depois do select $id');</script>";

//redirecting to the display page (index.php in our case)
header("Location:../select_dados_futuro_parceiro.php");
}else{

echo "<script type='text/javascript'>alert('ocorreu um erro, a variavel deve estar vazia $id');</script>";
}
*/
?>
